import type React from "react"
import type { Metadata } from "next"
import { Fira_Mono as FontMono } from "next/font/google"
import "./globals.css"
import { cn } from "@/lib/utils"

const fontMono = FontMono({
  subsets: ["latin"],
  variable: "--font-mono",
})

export const metadata: Metadata = {
  title: "DirAnalyze - Directory Analysis Tool",
  description: "Analyze directory structures easily",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={cn("min-h-screen bg-black font-mono antialiased", fontMono.variable)}>{children}</body>
    </html>
  )
}
