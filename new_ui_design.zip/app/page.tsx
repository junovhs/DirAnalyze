"use client"

import { useState } from "react"
import { Resizable } from "re-resizable"
import {
  FolderOpen,
  Upload,
  Copy,
  Download,
  Trash2,
  FileDigit,
  Terminal,
  BarChart2,
  ChevronRight,
  CheckSquare,
  Maximize,
  Minimize,
  Code,
  HelpCircle,
  FileJsonIcon as FileJs,
  FileCodeIcon as FileCss,
  FileIcon as FileHtml,
  FileText,
  FolderClosed,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function Home() {
  const [projectLoaded] = useState(true)
  const [helpOpen, setHelpOpen] = useState(false)

  // Function to get the appropriate file icon based on file extension
  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith(".js")) return <FileJs className="h-4 w-4 mr-2 text-yellow-400" />
    if (fileName.endsWith(".css")) return <FileCss className="h-4 w-4 mr-2 text-purple-400" />
    if (fileName.endsWith(".html")) return <FileHtml className="h-4 w-4 mr-2 text-orange-400" />
    return <FileText className="h-4 w-4 mr-2 text-lime-300" />
  }

  return (
    <main className="flex flex-col h-screen bg-black text-lime-500">
      {/* Header */}
      <header className="border-b border-lime-900 bg-black z-10 py-2 px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileDigit className="h-6 w-6 text-lime-500" />
            <h1 className="text-xl font-mono font-bold tracking-wider text-lime-500">DirAnalyze</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
              onClick={() => setHelpOpen(true)}
            >
              <HelpCircle className="mr-2 h-4 w-4" />
              Help
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
            >
              Settings
            </Button>
          </div>
        </div>
      </header>

      {/* Main content area with 3 panels */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left sidebar panel */}
        <Resizable
          defaultSize={{ width: 300, height: "100%" }}
          minWidth={250}
          maxWidth={600}
          enable={{ right: true }}
          className="border-r border-lime-900 bg-black"
          handleClasses={{
            right:
              "w-2 bg-lime-900 hover:bg-lime-600 cursor-col-resize transition-colors duration-200 absolute right-0 h-full",
          }}
        >
          <div className="flex flex-col h-full">
            <div className="p-4 border-b border-lime-900">
              <h2 className="font-mono text-sm text-lime-500 tracking-wider">PROJECT</h2>
            </div>

            <ScrollArea className="flex-1">
              <div className="p-4 space-y-4">
                {/* Action buttons */}
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Import AI Scaffold
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Scaffold Prompt
                  </Button>
                </div>

                <Separator className="my-4 bg-lime-900" />

                {/* Directory Tree Controls */}
                <div>
                  <h3 className="font-mono text-xs text-lime-500 mb-2 tracking-wider">DIRECTORY TREE CONTROLS</h3>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                    >
                      <CheckSquare className="mr-1 h-3 w-3" />
                      Select All
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                    >
                      <Code className="mr-1 h-3 w-3" />
                      Commit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                    >
                      <Maximize className="mr-1 h-3 w-3" />
                      Expand All
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                    >
                      <Minimize className="mr-1 h-3 w-3" />
                      Collapse All
                    </Button>
                  </div>
                </div>

                <Separator className="my-4 bg-lime-900" />

                {/* Directory Tree */}
                <div>
                  <h3 className="font-mono text-xs text-lime-500 mb-2 tracking-wider">DIRECTORY TREE</h3>
                  <div className="font-mono text-sm">
                    <div className="flex items-center py-1.5 px-2 bg-lime-950/20 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                      <FolderOpen className="h-5 w-5 mr-2 text-lime-400 flex-shrink-0" />
                      <span className="text-lime-400 truncate">TravelPerksDACC</span>
                      <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(33.92 KB)</span>
                    </div>

                    <div className="ml-4 border-l border-lime-900 pl-2 mt-1">
                      <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                        <FolderClosed className="h-5 w-5 mr-2 text-lime-400 flex-shrink-0" />
                        <span className="text-lime-400 truncate">api</span>
                        <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(4.13 KB)</span>
                      </div>

                      <div className="ml-4 border-l border-lime-900 pl-2">
                        <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                          <FileJs className="h-4 w-4 mr-2 text-yellow-400 flex-shrink-0" />
                          <span className="truncate">generate.js</span>
                          <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(4.13 KB)</span>
                        </div>
                      </div>

                      <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm mt-1">
                        <FolderClosed className="h-5 w-5 mr-2 text-lime-400 flex-shrink-0" />
                        <span className="text-lime-400 truncate">css</span>
                        <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(1.4 KB)</span>
                      </div>

                      <div className="ml-4 border-l border-lime-900 pl-2">
                        <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                          <FileCss className="h-4 w-4 mr-2 text-purple-400 flex-shrink-0" />
                          <span className="truncate">style.css</span>
                          <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(1.4 KB)</span>
                        </div>
                      </div>

                      <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm mt-1">
                        <FolderClosed className="h-5 w-5 mr-2 text-lime-400 flex-shrink-0" />
                        <span className="text-lime-400 truncate">js</span>
                        <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(24.54 KB)</span>
                      </div>

                      <div className="ml-4 border-l border-lime-900 pl-2">
                        <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                          <FileJs className="h-4 w-4 mr-2 text-yellow-400 flex-shrink-0" />
                          <span className="truncate">dmarc-parser.js</span>
                          <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(4.34 KB)</span>
                        </div>
                        <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                          <FileJs className="h-4 w-4 mr-2 text-yellow-400 flex-shrink-0" />
                          <span className="truncate">main.js</span>
                          <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(16.06 KB)</span>
                        </div>
                        <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm">
                          <FileJs className="h-4 w-4 mr-2 text-yellow-400 flex-shrink-0" />
                          <span className="truncate">ui-helpers.js</span>
                          <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(4.14 KB)</span>
                        </div>
                      </div>

                      <div className="flex items-center py-1.5 px-2 hover:bg-lime-950/40 cursor-pointer rounded-sm mt-1">
                        <FileHtml className="h-4 w-4 mr-2 text-orange-400 flex-shrink-0" />
                        <span className="truncate">index.html</span>
                        <span className="ml-2 text-xs text-lime-700 flex-shrink-0">(3.85 KB)</span>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="my-4 bg-lime-900" />

                {/* General Actions */}
                <div>
                  <h3 className="font-mono text-xs text-lime-500 mb-2 tracking-wider">GENERAL ACTIONS</h3>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      className="w-full justify-start border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Download ZIP
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Clear Project
                    </Button>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </div>
        </Resizable>

        {/* Center panel - Text report */}
        <div className="flex-1 overflow-hidden flex flex-col border-r border-lime-900 bg-black">
          <Tabs defaultValue="text-report" className="flex-1 flex flex-col">
            <div className="border-b border-lime-900 px-4">
              <TabsList className="h-10 bg-black">
                <TabsTrigger
                  value="text-report"
                  className="font-mono data-[state=active]:bg-lime-950 data-[state=active]:text-lime-400 data-[state=active]:shadow-none text-lime-500 hover:text-lime-400"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Text Report
                </TabsTrigger>
                <TabsTrigger
                  value="combine-mode"
                  className="font-mono data-[state=active]:bg-lime-950 data-[state=active]:text-lime-400 data-[state=active]:shadow-none text-lime-500 hover:text-lime-400"
                >
                  <ChevronRight className="h-4 w-4 mr-2" />
                  Combine Mode
                </TabsTrigger>
                <TabsTrigger
                  value="ai-patcher"
                  className="font-mono data-[state=active]:bg-lime-950 data-[state=active]:text-lime-400 data-[state=active]:shadow-none text-lime-500 hover:text-lime-400"
                >
                  <Terminal className="h-4 w-4 mr-2" />
                  AI Patcher
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="text-report" className="flex-1 p-0 m-0">
              {!projectLoaded ? (
                <div className="flex items-center justify-center h-full p-6">
                  <div className="text-center max-w-md">
                    <FileText className="h-12 w-12 text-lime-700 mx-auto mb-4" />
                    <h3 className="text-lg font-mono font-medium mb-2 text-lime-500">No Project Loaded</h3>
                    <p className="text-lime-700 mb-4">Drop a folder or select one to begin analysis</p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col h-full">
                  <div className="p-4 border-b border-lime-900 flex items-center">
                    <h3 className="font-mono text-sm text-lime-500 tracking-wider">COMPREHENSIVE TEXT REPORT</h3>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-4 font-mono text-sm whitespace-pre-wrap text-lime-300 bg-black">
                      {`//--- DIRANALYSE MATRIX REPORT (v3.2.1) ---//
// Timestamp: 2025-05-21T18:04:35.256Z
// Root Path: TravelPerksDACC
// Scope: Full scanned directory
// Note: File sizes reflect original scanned values.
//

//--- DIRECTORY STRUCTURE ---
TravelPerksDACC/ (Files: 6, Subdirs: 3, Size: 33.92 KB)
├── api/ (Files: 1, Subdirs: 0, Size: 4.13 KB)
│   └── generate.js (Size: 4.13 KB, Ext: .js)
├── css/ (Files: 1, Subdirs: 0, Size: 1.4 KB)
│   └── style.css (Size: 1.4 KB, Ext: .css)
├── js/ (Files: 3, Subdirs: 0, Size: 24.54 KB)
│   ├── dmarc-parser.js (Size: 4.34 KB, Ext: .js)
│   ├── main.js (Size: 16.06 KB, Ext: .js)
│   └── ui-helpers.js (Size: 4.14 KB, Ext: .js)
└── index.html (Size: 3.85 KB, Ext: .html)
//

//--- SUMMARY (Current View) ---
Total Files in View : 6
Total Folders in View : 4
Total Size (Original) : 33.92 KB
//

//--- END OF REPORT ---//`}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </TabsContent>

            <TabsContent value="combine-mode" className="flex-1 p-0 m-0">
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <p className="text-lime-700 font-mono">Combine Mode - Ready</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="ai-patcher" className="flex-1 p-0 m-0">
              <div className="flex flex-col h-full">
                <div className="p-4 border-b border-lime-900 flex items-center justify-between">
                  <h3 className="font-mono text-sm text-lime-500 tracking-wider">AI PATCHER</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Patch Prompt
                  </Button>
                </div>

                <div className="flex flex-col h-full">
                  <div className="p-4 border-b border-lime-900 bg-black">
                    <h4 className="font-mono text-xs text-lime-500 mb-2 tracking-wider">INSTRUCTIONS</h4>
                    <p className="text-lime-300 text-sm font-mono mb-4">
                      Paste the AI-generated JSON patch below. The system will analyze the changes and display a diff
                      view for review before applying.
                    </p>

                    <div className="border border-lime-900 bg-black p-2 mb-4">
                      <textarea
                        className="w-full h-32 bg-black text-lime-300 font-mono text-sm p-2 focus:outline-none focus:ring-1 focus:ring-lime-500 resize-none border-none"
                        placeholder='Paste JSON patch here... e.g. {"patches":[{"file":"main.js","changes":[{"type":"replace","line":42,"content":"// Fixed bug in calculation"}]}]}'
                      />
                    </div>

                    <Button className="w-full bg-lime-700 hover:bg-lime-600 text-black">
                      <Terminal className="mr-2 h-4 w-4" />
                      Review & Apply Patches
                    </Button>
                  </div>

                  <div className="flex-1 flex">
                    {/* Left side - Original code */}
                    <div className="w-1/2 border-r border-lime-900 overflow-hidden flex flex-col">
                      <div className="p-2 border-b border-lime-900 bg-lime-950/30">
                        <h4 className="font-mono text-xs text-lime-500 tracking-wider">ORIGINAL</h4>
                      </div>
                      <ScrollArea className="flex-1">
                        <div className="p-0 font-mono text-sm">
                          <div className="flex">
                            <div className="text-lime-700 text-right pr-2 w-10 select-none border-r border-lime-900 bg-black/50">
                              {Array.from({ length: 20 }, (_, i) => (
                                <div key={i} className="px-2 py-1 h-6">
                                  {i + 1}
                                </div>
                              ))}
                            </div>
                            <div className="flex-1 text-lime-300">
                              <div className="px-4 py-1 h-6">function calculateTotal(items) {`{`}</div>
                              <div className="px-4 py-1 h-6"> let total = 0;</div>
                              <div className="px-4 py-1 h-6"> </div>
                              <div className="px-4 py-1 h-6"> for (let i = 0; i &lt; items.length; i++) {`{`}</div>
                              <div className="px-4 py-1 h-6"> total += items[i].price;</div>
                              <div className="px-4 py-1 h-6"> {`}`}</div>
                              <div className="px-4 py-1 h-6"> </div>
                              <div className="px-4 py-1 h-6"> // Calculate tax (bug: incorrect tax rate)</div>
                              <div className="px-4 py-1 h-6 bg-red-900/50 border-l-4 border-red-500">
                                {" "}
                                const tax = total * 0.07;
                              </div>
                              <div className="px-4 py-1 h-6"> </div>
                              <div className="px-4 py-1 h-6"> return total + tax;</div>
                              <div className="px-4 py-1 h-6">{`}`}</div>
                              <div className="px-4 py-1 h-6"></div>
                              <div className="px-4 py-1 h-6">function formatCurrency(amount) {`{`}</div>
                              <div className="px-4 py-1 h-6"> return '$' + amount.toFixed(2);</div>
                              <div className="px-4 py-1 h-6">{`}`}</div>
                              <div className="px-4 py-1 h-6"></div>
                              <div className="px-4 py-1 h-6 bg-red-900/50 border-l-4 border-red-500">
                                // Missing discount function
                              </div>
                              <div className="px-4 py-1 h-6"></div>
                              <div className="px-4 py-1 h-6"></div>
                            </div>
                          </div>
                        </div>
                      </ScrollArea>
                    </div>

                    {/* Right side - Modified code */}
                    <div className="w-1/2 overflow-hidden flex flex-col">
                      <div className="p-2 border-b border-lime-900 bg-lime-950/30">
                        <h4 className="font-mono text-xs text-lime-500 tracking-wider">MODIFIED</h4>
                      </div>
                      <ScrollArea className="flex-1">
                        <div className="p-0 font-mono text-sm">
                          <div className="flex">
                            <div className="text-lime-700 text-right pr-2 w-10 select-none border-r border-lime-900 bg-black/50">
                              {Array.from({ length: 25 }, (_, i) => (
                                <div key={i} className="px-2 py-1 h-6">
                                  {i + 1}
                                </div>
                              ))}
                            </div>
                            <div className="flex-1 text-lime-300">
                              <div className="px-4 py-1 h-6">function calculateTotal(items) {`{`}</div>
                              <div className="px-4 py-1 h-6"> let total = 0;</div>
                              <div className="px-4 py-1 h-6"> </div>
                              <div className="px-4 py-1 h-6"> for (let i = 0; i &lt; items.length; i++) {`{`}</div>
                              <div className="px-4 py-1 h-6"> total += items[i].price;</div>
                              <div className="px-4 py-1 h-6"> {`}`}</div>
                              <div className="px-4 py-1 h-6"> </div>
                              <div className="px-4 py-1 h-6"> // Calculate tax with correct rate</div>
                              <div className="px-4 py-1 h-6 bg-green-900/50 border-l-4 border-green-500">
                                {" "}
                                const tax = total * 0.085;
                              </div>
                              <div className="px-4 py-1 h-6"> </div>
                              <div className="px-4 py-1 h-6"> return total + tax;</div>
                              <div className="px-4 py-1 h-6">{`}`}</div>
                              <div className="px-4 py-1 h-6"></div>
                              <div className="px-4 py-1 h-6">function formatCurrency(amount) {`{`}</div>
                              <div className="px-4 py-1 h-6"> return '$' + amount.toFixed(2);</div>
                              <div className="px-4 py-1 h-6">{`}`}</div>
                              <div className="px-4 py-1 h-6"></div>
                              <div className="px-4 py-1 h-6 bg-green-900/50 border-l-4 border-green-500">
                                // Apply discount to total
                              </div>
                              <div className="px-4 py-1 h-6 bg-green-900/50 border-l-4 border-green-500">
                                function applyDiscount(total, discountPercent) {`{`}
                              </div>
                              <div className="px-4 py-1 h-6 bg-green-900/50 border-l-4 border-green-500">
                                {" "}
                                return total * (1 - discountPercent / 100);
                              </div>
                              <div className="px-4 py-1 h-6 bg-green-900/50 border-l-4 border-green-500">{`}`}</div>
                              <div className="px-4 py-1 h-6"></div>
                            </div>
                          </div>
                        </div>
                      </ScrollArea>
                    </div>
                  </div>

                  {/* Log area */}
                  <div className="border-t border-lime-900 p-2 bg-black">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-mono text-xs text-lime-500 tracking-wider">PATCH LOG</h4>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                        >
                          Apply All
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                        >
                          Reject All
                        </Button>
                      </div>
                    </div>
                    <div className="border border-lime-900 bg-black p-2 h-32 overflow-auto font-mono text-xs">
                      <div className="text-lime-500">[SYSTEM] &gt; Analyzing patch data...</div>
                      <div className="text-lime-500">[SYSTEM] &gt; Found 2 changes in file main.js</div>
                      <div className="text-lime-500">[CHANGE] &gt; Line 9: Tax rate updated from 0.07 to 0.085</div>
                      <div className="text-lime-500">[CHANGE] &gt; Lines 19-21: Added new function applyDiscount()</div>
                      <div className="text-lime-500">
                        [SYSTEM] &gt; Ready to apply changes. Review the diff and confirm.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Bottom action bar */}
          <div className="border-t border-lime-900 p-2 flex justify-between items-center bg-black">
            <div className="text-lime-700 font-mono text-xs">
              {projectLoaded && "TravelPerksDACC // 6 files // 33.92 KB"}
            </div>
            <div className="flex gap-2">
              {projectLoaded && (
                <Button
                  size="sm"
                  variant="outline"
                  className="border-lime-900 text-lime-500 hover:bg-lime-950 hover:text-lime-400"
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Report
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Right panel - Statistics */}
        <Resizable
          defaultSize={{ width: 300, height: "100%" }}
          minWidth={250}
          maxWidth={400}
          enable={{ left: true }}
          className="bg-black"
          handleClasses={{
            left: "w-2 bg-lime-900 hover:bg-lime-600 cursor-col-resize transition-colors duration-200 absolute left-0 h-full",
          }}
        >
          <div className="flex flex-col h-full">
            <div className="p-4 border-b border-lime-900 flex items-center gap-2">
              <BarChart2 className="h-4 w-4 text-lime-500" />
              <h2 className="font-mono text-sm text-lime-500 tracking-wider">STATISTICS</h2>
            </div>

            <ScrollArea className="flex-1 p-4">
              <div className="space-y-6">
                <div>
                  <h3 className="font-mono text-xs text-lime-500 mb-3 tracking-wider">SELECTION SUMMARY</h3>
                  <div className="space-y-1 text-sm font-mono text-lime-300">
                    <p>Displaying stats for 6 selected files (33.92 KB) and 4 selected folder entries.</p>
                    <p>0 files (0 Bytes) and 0 folder entries were omitted from view.</p>
                  </div>
                </div>

                <Separator className="bg-lime-900" />

                <div>
                  <h3 className="font-mono text-xs text-lime-500 mb-3 tracking-wider">GLOBAL STATISTICS</h3>
                  <div className="grid grid-cols-2 gap-y-2 text-sm font-mono">
                    <div className="text-lime-700">Root Folder:</div>
                    <div className="text-lime-300">TravelPerksDACC</div>
                    <div className="text-lime-700">Files in View:</div>
                    <div className="text-lime-300">6</div>
                    <div className="text-lime-700">Folders in View:</div>
                    <div className="text-lime-300">4</div>
                    <div className="text-lime-700">Total Size:</div>
                    <div className="text-lime-300">33.92 KB</div>
                    <div className="text-lime-700">Deepest Level:</div>
                    <div className="text-lime-300">1</div>
                    <div className="text-lime-700">Avg. File Size:</div>
                    <div className="text-lime-300">5.65 KB</div>
                  </div>
                </div>

                <Separator className="bg-lime-900" />

                <div>
                  <h3 className="font-mono text-xs text-lime-500 mb-3 tracking-wider">FILE TYPE BREAKDOWN</h3>
                  <div className="border border-lime-900">
                    <div className="grid grid-cols-3 gap-2 text-xs font-mono font-bold bg-lime-950/30 p-2 border-b border-lime-900">
                      <div className="text-lime-400">Extension</div>
                      <div className="text-lime-400">Count</div>
                      <div className="text-lime-400">Total Size</div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm font-mono p-2 border-b border-lime-900 hover:bg-lime-950/20">
                      <div className="text-lime-300">.js</div>
                      <div className="text-lime-300">4</div>
                      <div className="text-lime-300">28.67 KB</div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm font-mono p-2 border-b border-lime-900 hover:bg-lime-950/20">
                      <div className="text-lime-300">.html</div>
                      <div className="text-lime-300">1</div>
                      <div className="text-lime-300">3.85 KB</div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm font-mono p-2 hover:bg-lime-950/20">
                      <div className="text-lime-300">.css</div>
                      <div className="text-lime-300">1</div>
                      <div className="text-lime-300">1.4 KB</div>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </div>
        </Resizable>
      </div>

      {/* Help Dialog */}
      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent className="bg-black border border-lime-900 text-lime-300 max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader className="border-b border-lime-900 pb-4">
            <DialogTitle className="text-lime-500 font-mono text-xl flex items-center">
              <HelpCircle className="mr-2 h-5 w-5" />
              DirAnalyze Help
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-8">
              <section>
                <h2 className="text-lime-500 font-mono text-lg mb-4">Getting Started</h2>
                <div className="space-y-4 text-lime-300">
                  <p>
                    DirAnalyze is a powerful tool for analyzing directory structures and making AI-assisted
                    modifications to your codebase.
                  </p>
                  <p>
                    To begin, either drag and drop a folder onto the application or use the "Select Folder" button in
                    the sidebar.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-lime-500 font-mono text-lg mb-4">Main Features</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lime-400 font-mono text-base mb-2 flex items-center">
                      <FileText className="mr-2 h-4 w-4" />
                      Text Report
                    </h3>
                    <p className="text-lime-300 ml-6">
                      Provides a comprehensive text-based analysis of your directory structure, including file counts,
                      sizes, and hierarchical organization.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lime-400 font-mono text-base mb-2 flex items-center">
                      <ChevronRight className="mr-2 h-4 w-4" />
                      Combine Mode
                    </h3>
                    <p className="text-lime-300 ml-6">
                      Allows you to merge and compare multiple directory structures, identifying differences and
                      similarities.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lime-400 font-mono text-base mb-2 flex items-center">
                      <Terminal className="mr-2 h-4 w-4" />
                      AI Patcher
                    </h3>
                    <p className="text-lime-300 ml-6">
                      Leverages AI to suggest and apply code modifications. Paste AI-generated JSON patches to see a
                      side-by-side diff view before applying changes.
                    </p>
                    <div className="ml-6 mt-2 space-y-2">
                      <p className="text-lime-300">
                        <span className="text-lime-400 font-bold">Step 1:</span> Generate a patch using an AI model of
                        your choice
                      </p>
                      <p className="text-lime-300">
                        <span className="text-lime-400 font-bold">Step 2:</span> Copy the JSON patch and paste it into
                        the AI Patcher input field
                      </p>
                      <p className="text-lime-300">
                        <span className="text-lime-400 font-bold">Step 3:</span> Review the changes in the diff view
                      </p>
                      <p className="text-lime-300">
                        <span className="text-lime-400 font-bold">Step 4:</span> Apply or reject the suggested changes
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-lime-500 font-mono text-lg mb-4">Directory Tree Controls</h2>
                <div className="space-y-2">
                  <div className="flex items-start">
                    <CheckSquare className="h-4 w-4 text-lime-400 mr-2 mt-1" />
                    <div>
                      <p className="text-lime-400 font-mono">Select All</p>
                      <p className="text-lime-300 text-sm">Selects all files in the directory tree for analysis</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Code className="h-4 w-4 text-lime-400 mr-2 mt-1" />
                    <div>
                      <p className="text-lime-400 font-mono">Commit</p>
                      <p className="text-lime-300 text-sm">Saves the current state of the analysis</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Maximize className="h-4 w-4 text-lime-400 mr-2 mt-1" />
                    <div>
                      <p className="text-lime-400 font-mono">Expand All</p>
                      <p className="text-lime-300 text-sm">Expands all folders in the directory tree</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Minimize className="h-4 w-4 text-lime-400 mr-2 mt-1" />
                    <div>
                      <p className="text-lime-400 font-mono">Collapse All</p>
                      <p className="text-lime-300 text-sm">Collapses all folders in the directory tree</p>
                    </div>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-lime-500 font-mono text-lg mb-4">Keyboard Shortcuts</h2>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <span className="text-lime-300">Open/Close Help</span>
                    <span className="text-lime-400 font-mono bg-lime-950/30 px-2 py-1">H</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lime-300">Select All Files</span>
                    <span className="text-lime-400 font-mono bg-lime-950/30 px-2 py-1">Ctrl+A</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lime-300">Copy Report</span>
                    <span className="text-lime-400 font-mono bg-lime-950/30 px-2 py-1">Ctrl+C</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lime-300">Switch to Text Report</span>
                    <span className="text-lime-400 font-mono bg-lime-950/30 px-2 py-1">Alt+1</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lime-300">Switch to Combine Mode</span>
                    <span className="text-lime-400 font-mono bg-lime-950/30 px-2 py-1">Alt+2</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lime-300">Switch to AI Patcher</span>
                    <span className="text-lime-400 font-mono bg-lime-950/30 px-2 py-1">Alt+3</span>
                  </div>
                </div>
              </section>
            </div>
          </ScrollArea>
          <div className="flex justify-end pt-4 border-t border-lime-900">
            <Button onClick={() => setHelpOpen(false)} className="bg-lime-700 hover:bg-lime-600 text-black">
              Close Help
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  )
}
